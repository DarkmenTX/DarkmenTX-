package com.filenamepro.mobile.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.core.graphics.createBitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.cyrillic.CyrillicTextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import android.graphics.pdf.PdfRenderer

class PdfProcessor(private val context: Context) {
    init { PDFBoxResourceLoader.init(context) }
    fun extractText(uri: Uri): String {
        val pdfText = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                PDDocument.load(input).use { document ->
                    PDFTextStripper().getText(document)
                }
            } ?: ""
        }.getOrDefault("")
        if (pdfText.isNotBlank() && DocumentParser.hasBirthEvent(pdfText) && Regex("\\d{2}\\.\\d{2}\\.\\d{4}").containsMatchIn(pdfText)) return pdfText
        val ocr = runCatching {
            val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: return@runCatching ""
            PdfRenderer(pfd).use { renderer ->
                if (renderer.pageCount == 0) return@runCatching ""
                renderer.openPage(0).use { page ->
                    val bitmap = createBitmap((page.width * 2.5).toInt(), (page.height * 2.5).toInt(), Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val image = InputImage.fromBitmap(bitmap, 0)
                    Tasks.await(TextRecognition.getClient(CyrillicTextRecognizerOptions.Builder().build()).process(image)).text
                }
            }
        }.getOrDefault("")
        return if (ocr.isBlank()) pdfText else ocr
    }
}
