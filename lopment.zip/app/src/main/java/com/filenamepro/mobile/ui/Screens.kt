package com.filenamepro.mobile.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.filenamepro.mobile.model.ProcessingState
import com.filenamepro.mobile.viewmodel.MainViewModel

@Composable fun HomeScreen(vm: MainViewModel, state: ProcessingState, onResults: () -> Unit, onSettings: () -> Unit) {
    val files = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.setFiles(it) }; val folder=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::setTree) }
    Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) { Text("FileName Pro Mobile", style=MaterialTheme.typography.headlineMedium); Button({files.launch(arrayOf("application/pdf"))}, Modifier.fillMaxWidth()) { Text("Выбрать PDF-файлы") }; OutlinedButton({folder.launch(null)}, Modifier.fillMaxWidth()) { Text(if(state.outputTree==null) "Выбрать папку для сохранения" else "Папка выбрана") }; LazyColumn(Modifier.weight(1f)) { items(state.files) { Text("PDF  ${it.lastPathSegment}", Modifier.padding(8.dp)) } }; if(state.processing) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Обработано ${state.processed} из ${state.files.size}"); OutlinedButton(vm::stop, Modifier.fillMaxWidth()) { Text("Остановить") } } else { Button({vm.process()}, enabled=state.files.isNotEmpty()&&state.outputTree!=null, Modifier.fillMaxWidth()) { Text("Обработать") } }; TextButton(onSettings) { Text("Настройки") }; if(state.results.isNotEmpty()) TextButton(onResults) { Text("Результаты") } }
}

@Composable fun ResultScreen(state: ProcessingState, onBack: () -> Unit) { val context=LocalContext.current; Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) { Text("Результаты", style=MaterialTheme.typography.headlineMedium); LazyColumn(Modifier.weight(1f)) { items(state.results) { r -> Text("${if(r.success) "✓" else "Ошибка"}  ${r.sourceName} → ${r.newName}", Modifier.padding(8.dp)) } }; Button({ context.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)) }, Modifier.fillMaxWidth()) { Text("Открыть папку с файлами") }; Button({ context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,state.results.joinToString("\\n") { "${it.sourceName};${it.newName};${it.missingDate}" ) }, "Поделиться")) }, Modifier.fillMaxWidth()) { Text("Поделиться результатом") }; TextButton(onBack) { Text("Назад") } } }

@Composable fun SettingsScreen(state: ProcessingState, vm: MainViewModel, onBack: () -> Unit) { Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) { Text("Настройки", style=MaterialTheme.typography.headlineMedium); Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Сохранять CSV-отчёт"); Switch(state.settingsCsv, vm::setCsv) }; Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Сохранять XLSX-отчёт"); Switch(state.settingsXlsx, vm::setXlsx) }; TextButton(onBack) { Text("Назад") } } }
