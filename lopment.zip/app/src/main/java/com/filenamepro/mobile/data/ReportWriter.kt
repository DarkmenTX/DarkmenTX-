package com.filenamepro.mobile.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.filenamepro.mobile.model.DocumentResult
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ReportWriter(private val context: Context) {
    fun csv(tree: Uri, rows: List<DocumentResult>): Uri? {
        val file = DocumentFile.fromTreeUri(context, tree)?.createFile("text/csv", "FileNamePro_report.csv") ?: return null
        val body = buildString {
            append("\uFEFFЛичный номер;ФИО;Дата БВП\n")
            rows.forEach { append(listOf(it.personalNumber, it.fio, it.missingDate).joinToString(";") { value -> value.csv() }); append('\n') }
        }
        context.contentResolver.openOutputStream(file.uri)?.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        return file.uri
    }

    fun xlsx(tree: Uri, rows: List<DocumentResult>): Uri? {
        val file = DocumentFile.fromTreeUri(context, tree)?.createFile(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "FileNamePro_report.xlsx"
        ) ?: return null
        val values = listOf(listOf("Личный номер", "ФИО", "Дата БВП")) + rows.map { listOf(it.personalNumber, it.fio, it.missingDate) }
        val workbook = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Отчёт" sheetId="1" r:id="rId1"/></sheets></workbook>"""
        val sheet = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${values.mapIndexed { index, row -> "<row r=\"${index + 1}\">${row.mapIndexed { column, value -> "<c r=\"${('A'.code + column).toChar()}${index + 1}\" t=\"inlineStr\"><is><t>${value.xml()}</t></is></c>" }.joinToString("")}</row>" }.joinToString("")}</sheetData></worksheet>"""
        val contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>"
        val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"
        val workbookRels = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>"
        val bytes = ByteArrayOutputStream()
        ZipOutputStream(bytes).use { zip -> listOf("[Content_Types].xml" to contentTypes, "_rels/.rels" to rels, "xl/workbook.xml" to workbook, "xl/_rels/workbook.xml.rels" to workbookRels, "xl/worksheets/sheet1.xml" to sheet).forEach { (name, value) -> zip.putNextEntry(ZipEntry(name)); zip.write(value.toByteArray()); zip.closeEntry() } }
        context.contentResolver.openOutputStream(file.uri)?.use { it.write(bytes.toByteArray()) }
        return file.uri
    }

    private fun String.csv() = replace("\"", "\"\"").let { if (contains(';') || contains('\n') || contains('"')) "\"$it\"" else it }
    private fun String.xml() = replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
}
