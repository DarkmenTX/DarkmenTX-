package com.filenamepro.mobile.model

data class DocumentResult(val sourceName: String, val newName: String, val personalNumber: String = "", val fio: String = "", val missingDate: String = "", val success: Boolean, val error: String = "")

data class ProcessingState(val files: List<android.net.Uri> = emptyList(), val outputTree: android.net.Uri? = null, val results: List<DocumentResult> = emptyList(), val processed: Int = 0, val processing: Boolean = false, val settingsCsv: Boolean = true, val settingsXlsx: Boolean = false)
