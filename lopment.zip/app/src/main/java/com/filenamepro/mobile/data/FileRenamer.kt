package com.filenamepro.mobile.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.filenamepro.mobile.model.DocumentResult

class FileRenamer(private val context: Context) {
    fun copy(source: Uri, tree: Uri, desired: String): Uri {
        val dir = DocumentFile.fromTreeUri(context, tree) ?: error("Папка недоступна")
        val safe = desired.replace(Regex("[<>:\"/\\\\|?*]"), "_")
        val base = safe.removeSuffix(".pdf"); var candidate = "$base.pdf"; var i = 2
        while (dir.findFile(candidate) != null) candidate = "$base(${i++}).pdf"
        val target = dir.createFile("application/pdf", candidate) ?: error("Не удалось создать файл")
        context.contentResolver.openInputStream(source)!!.use { input -> context.contentResolver.openOutputStream(target.uri)!!.use { output -> input.copyTo(output) } }
        return target.uri
    }
}
