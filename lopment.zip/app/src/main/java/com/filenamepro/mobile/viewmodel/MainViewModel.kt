package com.filenamepro.mobile.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.filenamepro.mobile.data.*
import com.filenamepro.mobile.model.ProcessingState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.ensureActive

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(ProcessingState()); val state = _state.asStateFlow(); private var job: Job? = null
    private val prefs = app.getSharedPreferences("settings", 0)
    private val processor = PdfProcessor(app); private val renamer = FileRenamer(app); private val reports = ReportWriter(app)
    init { _state.value = _state.value.copy(settingsCsv = prefs.getBoolean("csv", true), settingsXlsx = prefs.getBoolean("xlsx", false)) }
    fun setFiles(v: List<Uri>) { _state.value = _state.value.copy(files = v) }
    fun setTree(v: Uri) { _state.value = _state.value.copy(outputTree = v) }
    fun setCsv(v: Boolean) { prefs.edit().putBoolean("csv",v).apply(); _state.value = _state.value.copy(settingsCsv=v) }
    fun setXlsx(v: Boolean) { prefs.edit().putBoolean("xlsx",v).apply(); _state.value = _state.value.copy(settingsXlsx=v) }
    fun process() { val s = _state.value; val tree=s.outputTree ?: return; job=viewModelScope.launch(Dispatchers.IO) { _state.value=s.copy(processing=true,processed=0,results=emptyList()); val result=mutableListOf<com.filenamepro.mobile.model.DocumentResult>(); s.files.forEachIndexed { index, uri -> ensureActive(); val name=uri.lastPathSegment?.substringAfterLast('/') ?: "document.pdf"; val parsed=runCatching { DocumentParser.parse(name, processor.extractText(uri)) }.getOrElse { DocumentParser.parse(name, "") }; runCatching { renamer.copy(uri,tree,parsed.newName) }.onFailure { result += parsed.copy(success=false,error=it.message ?: "Ошибка") }.onSuccess { result += parsed }; _state.value=_state.value.copy(processed=index+1,results=result) }; if(s.settingsCsv) reports.csv(tree,result); if(s.settingsXlsx) reports.xlsx(tree,result); _state.value=_state.value.copy(processing=false) } }
    fun stop() { job?.cancel(); _state.value = _state.value.copy(processing=false) }
}
