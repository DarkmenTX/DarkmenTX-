package com.filenamepro.mobile.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Blue = Color(0xFF1D62D4)
@Composable fun FileNameProTheme(content: @Composable () -> Unit) { val dark=isSystemInDarkTheme(); val scheme=if(dark) darkColorScheme(primary=Blue) else lightColorScheme(primary=Blue); MaterialTheme(colorScheme=scheme, content=content) }
