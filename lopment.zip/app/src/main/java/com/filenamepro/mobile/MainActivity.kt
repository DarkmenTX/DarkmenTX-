package com.filenamepro.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.material3.*
import com.filenamepro.mobile.ui.*
import com.filenamepro.mobile.viewmodel.MainViewModel
import com.filenamepro.mobile.ui.theme.FileNameProTheme

class MainActivity : ComponentActivity() {
    private val vm by viewModels<MainViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { FileNameProTheme { val state by vm.state.collectAsState(); var screen by remember { mutableStateOf("home") }; when(screen) { "results" -> ResultScreen(state) { screen="home" }; "settings" -> SettingsScreen(state,vm) { screen="home" }; else -> HomeScreen(vm,state,{screen="results"},{screen="settings"}) } } } }
}
