package com.filenamepro.mobile.data

import com.filenamepro.mobile.model.DocumentResult

object DocumentParser {
    private val fioRegex = Regex("\\b[А-ЯЁа-яё]{3,30}\\s+[А-ЯЁа-яё]{3,30}\\s+[А-ЯЁа-яё]{3,30}\\b")
    private val numberRegex = Regex("\\b[А-ЯЁа-яёA-Za-z]{1,2}\\s*[-.]?\\s*\\d(?:[\\s.-]?\\d){5}\\b")
    private val dateRegex = Regex("\\b\\d{2}\\.\\d{2}\\.\\d{4}\\b")
    private val ranks = setOf("рядовой","сержант","лейтенант","капитан","майор","полковник","солдат","ефрейтор","военнослужащий","воинской","части","статья")
    fun hasBirthEvent(text: String) = Regex("(?i)(пропал\\s+без\\s+вести|погиб|умер)").containsMatchIn(text)
    fun parse(source: String, text: String): DocumentResult {
        val normalized = text.replace('B','В').replace('C','С').replace('E','Е').replace('X','Х').replace('A','А').replace('b','в').replace('c','с').replace('e','е').replace('x','х').replace('a','а').replace('№', ' ')
            .replace(Regex("\\s+"), " ").trim()
        val event = Regex("(?i)(пропал\\s+без\\s+вести|погиб|умер)").find(normalized)
        val date = event?.let { dateRegex.find(normalized.substring(it.range.last + 1, (it.range.last + 221).coerceAtMost(normalized.length)))?.value } ?: ""
        val main = if (event != null) normalized.substring(0, event.range.first) else normalized
        val fio = fioRegex.findAll(main).map { it.value }.lastOrNull { it.lowercase().split(" ").none { word -> word in ranks } } ?: ""
        val number = numberRegex.find(normalized)?.value?.replace(Regex("[\\s.-]"), "")?.uppercase() ?: ""
        return if (fio.isNotBlank() && number.isNotBlank()) DocumentResult(source, "$fio $number.pdf", number, fio, date, true) else DocumentResult(source, "Не распознано — $source", missingDate = date, success = false, error = "Не удалось найти ФИО или личный номер")
    }
}
